var init = false
var swiper
function swiperCard() {
	if (window.innerWidth < 768) {
		if (!init) {
			init = true
			swiper = new Swiper('.swiper', {
				slidesPerView: 'auto',
				spaceBetween: 20,
				freeMode: true,
				pagination: {
					el: '.swiper-pagination',
					clickable: true,
				},
				keyboard: {
					enabled: true,
					onlyInViewport: true,
					pageUpDown: true,
				},
				mousewheel: {
					sensitivity: 1,
				},
			})
		}
	} else if (init) {
		swiper.destroy()
		init = false
	}
}
swiperCard()
window.addEventListener('resize', swiperCard)

/* var popup = document.querySelector('.modal')



openPopupButton.addEventListener('click', function (evt) {
	evt.preventDefault()
	popup.classList.add('modal--show')
})

closePopupButton.addEventListener('click', function (evt) {
	popup.classList.remove('modal--show')
})
	
var thumbnails = document.querySelectorAll('.gallery__photo-preview')
var fullPhoto = document.querySelector('.full-photo')

var addThumbnailClickHandler = function (thumbnail, photo) {
	thumbnail.addEventListener('click', function () {
		fullPhoto.src = photo
	})
}

for (var i = 0; i < thumbnails.length; i++) {
	addThumbnailClickHandler(thumbnails[i], photos[i])
}

*/

var div = document.getElementById()
var display = 0

function hideShow() {
	if (display == 1) {
		div.style.display = 'block'
		display = 0
	} else {
		div.style.display = 'none'
		display = 1
	}
}
